import model from '../Models/index'

export const sequelizeConnect=()=>{
    model.sequelize
    .sync({
        //alter:true
    })
    .then(()=>{
        console.log("MYSQL BOOTSTRAP::SUCCESS");
    }).
    catch((error)=>{
        console.log(`Error connecting to database::${JSON.stringify(error)}`);
    });
};
export default sequelizeConnect;