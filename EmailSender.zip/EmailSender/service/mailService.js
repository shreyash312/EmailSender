
import { error, info } from 'console';
import { reject } from 'lodash'
import nodemailer from 'nodemailer'
import { resolve } from 'path'

function sendEmail(to,subject,text){

    return new Promise((resolve,reject)=>{

        let transporter=nodemailer.createTestAccount({
            host:'smtp.ethereal.email',
            port:587,
            secure:false,
            auth:{
                user:'cierra.turner12@ethereal.email',
                pass:'8vkf9ZVkfS78wksnh8'
            },
            tls:{
                rejectUnauthorized:false
            }
        });

        //email content
        let mailOptions={
            from:'cierra.turner12@ethereal.email',
            to:to,
            subject:subject,
            text:text
        };

        //send mail
        transporter.sendEmail(mailOptions,(error,info)=>{
            if(error){
                console.log(error);
                reject('Error in sending mail')
            }else{
                console.log('Email sent :'+info.response)
                resolve('Email sent successfully')
            }
        })
    })
}

export default sendEmail;