
import moment from "moment";
const Models = require('../Models')
const sequelize = require('../Models')
const payloadModel = Models.payload

class commonQueries{
    async savePayload(data){
        return payloadModel.create(data)
    }

}

export default new commonQueries();