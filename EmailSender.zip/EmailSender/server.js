import Express  from 'express';
import moment from 'moment-timezone'
import sequelizeConnect from './Config/sequelizeConfig'
const app= Express();
import Router from './Routes/index'
const {PORT,SEQUELIZE_CONNECTION} =process.env;

app.use(Express.json())

if(SEQUELIZE_CONNECTION==="Y"){
    sequelizeConnect()
}
app.use('/',Router)
process.on("uncaughtException",function(error){
    console.log("APP ERROR",error);
})

app.listen(PORT,()=>{
    console.log(`App started on port :: ${PORT} on ${moment().format('DD-MM-YYYYTHH:mm:ss.S')} `)
})

