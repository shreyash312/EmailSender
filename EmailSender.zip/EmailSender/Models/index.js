import { Sequelize } from "sequelize";
import { readdirSync } from "fs";
import { basename as _basename, join } from "path";
const basename=_basename(__filename);

const {
    MYSQL_HOST,
MYSQL_PASSWORD,
MYSQL_USERNAME,
MYSQL_DB_NAME,
MYSQL_PORT
} = process.env

const db = {}

const sequelizeInit = new Sequelize(
    MYSQL_DB_NAME,
    MYSQL_USERNAME,
    MYSQL_PASSWORD,{
        host:MYSQL_HOST,
        port:MYSQL_PORT,
        dialect:'mysql',
        dialectOptions:{useUTC:false},
        timezone:'+05:30',
        pool:{
            max:5,
            min:0,
            acquire:30000,
            idle:10000
        }
    }
);

readdirSync(__dirname)
    .filter(
        (file)=>file.indexOf(".") !== 0 && file !==basename && file.slice(-3)===".js"
    )
    .forEach((file)=>{
        const model=require(join(__dirname,file))(sequelizeInit,Sequelize);
    });

    Object.keys(db).forEach((modelName)=>{
        if(db[modelName].associate){
            db[modelName].associate(db);
        }
    });

    db.sequelize = sequelizeInit;
    db.Sequelize = Sequelize;

  export default db;
