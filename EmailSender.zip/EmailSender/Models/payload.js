

import sequelize from 'sequelize'
const tableName='payload'

module.exports=(sequelize,DataTypes)=>{
    const modelName = sequelize.define(
        tableName,
        {
            id:{
                type:DataTypes.INTEGER(30),
                autoIncrement:true,
                primaryKey:true
            },
            log_point:{
                type:DataTypes.STRING(64),
                allowNull:true
            },
            endpoint:{
                type:DataTypes.STRING(64),
                allowNull:true
            },
            request_data:{
                type:DataTypes.JSON,
                allowNull:true
            },
            payload_data:{
                type:DataTypes.JSON,
                allowNull:true
            },
            createdAt:{
                field:'created_at',
                type:DataTypes.DATE,
                defaultValue:sequelize.fn('now')
            },
            updatedAt:{
                field:'updated_at',
                type:DataTypes.DATE,
                defaultValue:sequelize.fn('now')
            }
        }
    )

    return modelName
}