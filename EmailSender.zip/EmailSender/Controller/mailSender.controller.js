
import emailService from '../service/mailService'
import commonQueries from '../service/commonQueries'

let _this
class triggerMailController{
    constructor(){
        _this=this
        this.validateOptions={
            abortEarly:false,
            errors:{
                wrap:{
                    label: ''
                }
            }
        }
    }

    async triggerMail(req,res){
        const{to,subject,text}=req?.body?.data;
        const startTime = new Date();
        const endpoint=`${req.originalUrl}`;
        const logpoint="SEND_EMAIL";

        try {
            const result = await emailService(to,subject,text)
            console.log(result);

            const payload={
                log_point:logpoint,
                endpoint:endpoint,
                request_data:req?.body?.data,
                payload_data:result
            }
            const savePayload=await commonQueries.savePayload(result)
            console.log(savePayload)
            res.status(200).send(result);

        } catch (error) {
             res.status(500).send(error);
        }

    }

}

export default new triggerMailController();