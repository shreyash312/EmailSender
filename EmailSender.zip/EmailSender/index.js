require('dotenv').config()

require('./server')