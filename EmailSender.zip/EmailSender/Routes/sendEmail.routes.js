
import express from 'express'

import triggerMailController from '../Controller/mailSender.controller'

const sendEmailRouter = express.Router();

sendEmailRouter.post('/',triggerMailController.triggerMail)

export {sendEmailRouter}