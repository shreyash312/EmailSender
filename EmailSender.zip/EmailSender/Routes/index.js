import express from 'express'

import { sendEmailRouter } from './sendEmail.routes'

const Router = express.Router();

const{BASE_ROUTE}=process.env;

Router.use(`${BASE_ROUTE}/sendMail`,sendEmailRouter);

export default Router;

